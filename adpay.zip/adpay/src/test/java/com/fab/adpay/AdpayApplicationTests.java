package com.fab.adpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
